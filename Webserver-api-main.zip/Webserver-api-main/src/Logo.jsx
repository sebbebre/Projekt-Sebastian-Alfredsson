import './Logo.css';

function Logo(){
    return (
        <div className='logo-box'>
            <div className='logo'></div>
        </div>
    )
}
export default Logo;