import './BoxText.css';



function BoxText() {
    return (
        <div className='box-texts'>
            <div className='outfit-text'>
                
            </div>
            <div className='backbling-text'>

            </div>
            <div className='pickaxe-text'>

            </div>
            <div className='glider-text'>

            </div>
        </div>
    )
}
export default BoxText;