import java.io.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.regex.*;

public class UserDatabase {
    private final Map<String, User> users = new HashMap<>();
    private final String USERS_SER_FILE = "users.ser";
    private final String BALANCES_FILE = "balances.txt";

    public UserDatabase() {
        loadSerializedUsers();
    }

    public void loadUsersFromTxtFile() {
        try (Scanner scanner = new Scanner(new File("users.txt"));
             BufferedWriter balanceWriter = new BufferedWriter(new FileWriter(BALANCES_FILE));
             ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(USERS_SER_FILE))) {

            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",");
                if (parts.length != 7) continue;

                String username = parts[0], password = parts[1], firstName = parts[2],
                       lastName = parts[3], address = parts[4], phone = parts[5], balance = parts[6];

                if (isValid(username, password, firstName, lastName, address, phone, balance)) {
                    String hashed = hashPassword(password);
                    User user = new User(username, hashed, firstName, lastName, address, phone);
                    out.writeObject(user);
                    users.put(username, user);
                    balanceWriter.write(username + "," + balance + "\n");
                }
            }

            new File("users.txt").delete();  // delete input file

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadSerializedUsers() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(USERS_SER_FILE))) {
            while (true) {
                try {
                    User user = (User) in.readObject();
                    users.put(user.getUsername(), user);
                } catch (EOFException e) {
                    break;
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("No serialized users loaded: " + e.getMessage());
        }
    }

    private boolean isValid(String u, String p, String f, String l, String a, String ph, String b) {
        return u.matches("^[a-zA-Z]\\w{4,11}$") &&
               p.matches("^(?=.*[A-Z])(?=.*[!@#])(?=.*\\d).{8,}$") &&
               f.matches("^[a-zA-Z]+$") &&
               l.matches("^[a-zA-Z]+$") &&
               a.matches("^.{5,50}$") &&
               ph.matches("^\\+46\\d{7,9}$") &&
               b.matches("^\\d+$");
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hash);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public boolean authenticate(String username, String password) {
        User user = users.get(username);
        return user != null && user.getHashedPassword().equals(hashPassword(password));
    }

    public int getBalance(String username) throws IOException {
        try (Scanner scanner = new Scanner(new File(BALANCES_FILE))) {
            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",");
                if (parts[0].equals(username)) return Integer.parseInt(parts[1]);
            }
        }
        return 0;
    }

public void updateBalance(String username, int newBalance) throws IOException {
    List<String> lines = new ArrayList<>();
    Scanner scanner = new Scanner(new File("balances.txt"));

    try {
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            if (line.startsWith(username + ",")) {
                lines.add(username + "," + newBalance);  
            } else {
                lines.add(line);
            }
        }
    } finally {
        scanner.close();
    }


    BufferedWriter writer = new BufferedWriter(new FileWriter("balances.txt"));
    for (String line : lines) {
        writer.write(line + "\n");
    }
    writer.close();
}

    public void logTransaction(String username, String type, int amount) throws IOException {
        try (Formatter formatter = new Formatter(new FileWriter("history_" + username + ".log", true))) {
            formatter.format("[%s] %s %d%n", new Date(), type.toUpperCase(), amount);
        }
    }
}