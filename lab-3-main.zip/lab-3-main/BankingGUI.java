import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BankingGUI extends JFrame {
    private final JTextArea outputArea;
    private final JButton depositButton, withdrawButton, transferButton;
    private final JRadioButton showHistoryButton, hideHistoryButton;
    private final UserDatabase db = new UserDatabase();
    private String currentUser;

    public BankingGUI(String username) {
        super("Banking - " + username);
        currentUser = username;

        setSize(500, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new BorderLayout());
        JLabel welcome = new JLabel("Welcome, " + username, SwingConstants.CENTER);
        topPanel.add(welcome, BorderLayout.NORTH);

        outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);
        topPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel radioPanel = new JPanel();
        showHistoryButton = new JRadioButton("Show History", true);
        hideHistoryButton = new JRadioButton("Hide History");
        ButtonGroup group = new ButtonGroup();
        group.add(showHistoryButton);
        group.add(hideHistoryButton);
        radioPanel.add(showHistoryButton);
        radioPanel.add(hideHistoryButton);
        topPanel.add(radioPanel, BorderLayout.SOUTH);

        hideHistoryButton.addActionListener(e -> refreshBalance());

        add(topPanel, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new GridLayout(1, 3));
        depositButton = new JButton("Deposit");
        withdrawButton = new JButton("Withdraw");
        transferButton = new JButton("Transfer");
        buttons.add(depositButton);
        buttons.add(withdrawButton);
        buttons.add(transferButton);
        add(buttons, BorderLayout.SOUTH);

        ActionListener handler = new TransactionHandler();
        depositButton.addActionListener(handler);
        withdrawButton.addActionListener(handler);
        transferButton.addActionListener(handler);

        refreshBalance();
        setVisible(true);
    }

    private void refreshBalance() {
        try {
            int balance = db.getBalance(currentUser);
            outputArea.setText("Current Balance: " + balance + "\n");
        } catch (Exception e) {
            outputArea.setText("Error loading balance.");
        }
    }

    private class TransactionHandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String type = ((JButton) e.getSource()).getText().toLowerCase();
            String input = JOptionPane.showInputDialog(BankingGUI.this, "Enter amount to " + type + ":");
            if (input == null) return;

            try {
                int amount = Integer.parseInt(input.trim());
                int balance = db.getBalance(currentUser);
                if ((type.equals("withdraw") || type.equals("transfer")) && amount > balance) {
                    throw new Exception("Insufficient funds.");
                }

                int newBalance = type.equals("deposit") ? balance + amount : balance - amount;
                db.updateBalance(currentUser, newBalance);
                db.logTransaction(currentUser, type, amount);

                if (hideHistoryButton.isSelected()) {
                    refreshBalance();
                } else {
                    outputArea.append(type + "ed: " + amount + "\n");
                    outputArea.append("New Balance: " + newBalance + "\n");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(BankingGUI.this, "Invalid number", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(BankingGUI.this, ex.getMessage(), "Transaction Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        UserDatabase db = new UserDatabase();
        //db.loadUsersFromTxtFile();

        String user = JOptionPane.showInputDialog(null, "Enter username:");
        String pass = JOptionPane.showInputDialog(null, "Enter password:");

        if (db.authenticate(user, pass)) {
            new BankingGUI(user);
        } else {
            JOptionPane.showMessageDialog(null, "Login failed.");
        }
    }
}
