

public class BankAccountManager {
    private int balance = 10000;

    public void deposit(int amount){
        if (amount <= 0) {
            throw new InvalidTransactionException("Deposit amount must be positive.");
        }
        balance += amount;
    }

    public void withdraw(int amount){
        int result = balance-amount;

        if(amount<=0){
            throw new InvalidTransactionException("Amount must be positive.");
        }

        if(result <0){
            throw new InvalidTransactionException("Insufficient funds.");
        }

        balance -= amount;
    }

    public void transfer(int amount){
        int result = balance-amount; 

        if(amount<=0){
            throw new InvalidTransactionException("Transfer amount must be positive.");
        }

        if(result < 0){
            throw new InvalidTransactionException("Insufficient funds.");
        }

        balance-=amount;
    }

    public int getBalance(){

        return balance;
    }

    
    public void processTransaction(String type, int amount) {
    switch (type.toLowerCase()) {
        case "deposit":
            deposit(amount);
            break;
        case "withdraw":
            withdraw(amount);
            break;
        case "transfer":
            transfer(amount);
            break;
        default:
            throw new UnknownTransactionTypeException("Invalid transaction type: " + type);
    }
}

}
