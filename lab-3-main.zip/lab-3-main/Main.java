import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BankAccountManager manager = new BankAccountManager();
        List<Throwable> errorHistory = new ArrayList<>();

        while(true){
            System.out.print("Welcome to Your Banking Application\n");
            System.out.print("Choose transaction (deposit, withdraw, transfer, balance, exit): ");
            String input = sc.nextLine().trim().toLowerCase();

            if(input == "exit") break;

            if (input.equals("balance")) {
                System.out.println("Current balance: " + manager.getBalance());
                System.out.println("...Logging attempt...");
                continue;
            }
        
            try {
                System.out.print("Enter amount: ");
                int amount = Integer.parseInt(sc.nextLine().trim());
                manager.processTransaction(input, amount);
            } 
            
            catch (Throwable e) {
                errorHistory.add(e);
                System.out.println("!! Error: " + e.getMessage());
            } 
            
            finally {
                System.out.println("...Logging attempt...");
            }
        }

        System.out.println(">>> Stack Traces of All Caught Exceptions <<<");
        for (Throwable e : errorHistory) {
            e.printStackTrace();
        }
        System.out.println("Exiting program. Thank you!");
    }
}
