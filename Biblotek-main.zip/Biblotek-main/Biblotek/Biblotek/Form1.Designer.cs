﻿namespace Biblotek
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.choice = new System.Windows.Forms.Panel();
            this.LoginButton = new System.Windows.Forms.Button();
            this.RegisterButton = new System.Windows.Forms.Button();
            this.login = new System.Windows.Forms.Panel();
            this.LogButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.LoginPasswordBox = new System.Windows.Forms.TextBox();
            this.LoginUsernameBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.register = new System.Windows.Forms.Panel();
            this.RegButton = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.numberBox = new System.Windows.Forms.TextBox();
            this.mailBox = new System.Windows.Forms.TextBox();
            this.passwordBox = new System.Windows.Forms.TextBox();
            this.usernameBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.mainpage = new System.Windows.Forms.Panel();
            this.AdminAddButton = new System.Windows.Forms.Button();
            this.AdminButton = new System.Windows.Forms.Button();
            this.SearchbookButton = new System.Windows.Forms.Button();
            this.MybooksButton = new System.Windows.Forms.Button();
            this.ProfilButton = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.Profil = new System.Windows.Forms.Panel();
            this.ProfilPassword = new System.Windows.Forms.TextBox();
            this.ProfilUsername = new System.Windows.Forms.TextBox();
            this.applyAdminButton = new System.Windows.Forms.Button();
            this.changePasswordButton = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.searchbooks = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.findBookButton = new System.Windows.Forms.Button();
            this.borrowButton = new System.Windows.Forms.Button();
            this.bookNumberBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.listBox = new System.Windows.Forms.ListBox();
            this.searchTextBox = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.Mybooks = new System.Windows.Forms.Panel();
            this.returnReservedButton = new System.Windows.Forms.Button();
            this.reservedTextBox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.borrwingListBox = new System.Windows.Forms.ListBox();
            this.returnButton = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.returnBox = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.reservedListBox = new System.Windows.Forms.ListBox();
            this.AdminSettings = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.showAllUsersButton = new System.Windows.Forms.Button();
            this.removeUserButton = new System.Windows.Forms.Button();
            this.addUserButton = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.showAllUsers = new System.Windows.Forms.Panel();
            this.allUsersBox = new System.Windows.Forms.ListBox();
            this.MainPageButton = new System.Windows.Forms.Button();
            this.AdminBookSettings = new System.Windows.Forms.Panel();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.changePassword = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.passwordButton = new System.Windows.Forms.Button();
            this.changePasswordTextBox = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.createBook = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.createBookButton = new System.Windows.Forms.Button();
            this.stockTextBox = new System.Windows.Forms.TextBox();
            this.isbnTextBox = new System.Windows.Forms.TextBox();
            this.yearTextBox = new System.Windows.Forms.TextBox();
            this.authorTextBox = new System.Windows.Forms.TextBox();
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.removeBook = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.booksBox = new System.Windows.Forms.ListBox();
            this.removeBookButton = new System.Windows.Forms.Button();
            this.removeBookTextBox = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.editBook = new System.Windows.Forms.Panel();
            this.button9 = new System.Windows.Forms.Button();
            this.bookButtonPick = new System.Windows.Forms.Button();
            this.bookNumberEdit = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.bookBoxList = new System.Windows.Forms.ListBox();
            this.editBookPicked = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.editBookButton = new System.Windows.Forms.Button();
            this.whatToChangeItTo = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.whatToChange = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.bookEditBox = new System.Windows.Forms.ListBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.createUser = new System.Windows.Forms.Panel();
            this.createUserButton = new System.Windows.Forms.Button();
            this.numberText = new System.Windows.Forms.TextBox();
            this.mailText = new System.Windows.Forms.TextBox();
            this.passwordText = new System.Windows.Forms.TextBox();
            this.usernameText = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.RemoveUser = new System.Windows.Forms.Panel();
            this.removeButton = new System.Windows.Forms.Button();
            this.removeUserTextBox = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.userListBox = new System.Windows.Forms.ListBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.choice.SuspendLayout();
            this.login.SuspendLayout();
            this.register.SuspendLayout();
            this.mainpage.SuspendLayout();
            this.Profil.SuspendLayout();
            this.searchbooks.SuspendLayout();
            this.Mybooks.SuspendLayout();
            this.AdminSettings.SuspendLayout();
            this.showAllUsers.SuspendLayout();
            this.AdminBookSettings.SuspendLayout();
            this.changePassword.SuspendLayout();
            this.createBook.SuspendLayout();
            this.removeBook.SuspendLayout();
            this.editBook.SuspendLayout();
            this.editBookPicked.SuspendLayout();
            this.createUser.SuspendLayout();
            this.RemoveUser.SuspendLayout();
            this.SuspendLayout();
            // 
            // choice
            // 
            this.choice.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.choice.Controls.Add(this.LoginButton);
            this.choice.Controls.Add(this.RegisterButton);
            this.choice.Location = new System.Drawing.Point(0, 0);
            this.choice.Name = "choice";
            this.choice.Size = new System.Drawing.Size(801, 452);
            this.choice.TabIndex = 0;
            // 
            // LoginButton
            // 
            this.LoginButton.Location = new System.Drawing.Point(415, 174);
            this.LoginButton.Name = "LoginButton";
            this.LoginButton.Size = new System.Drawing.Size(200, 70);
            this.LoginButton.TabIndex = 1;
            this.LoginButton.Text = "Logga in";
            this.LoginButton.UseVisualStyleBackColor = true;
            this.LoginButton.Click += new System.EventHandler(this.LoginButton_Click);
            // 
            // RegisterButton
            // 
            this.RegisterButton.Location = new System.Drawing.Point(159, 174);
            this.RegisterButton.Name = "RegisterButton";
            this.RegisterButton.Size = new System.Drawing.Size(200, 70);
            this.RegisterButton.TabIndex = 0;
            this.RegisterButton.Text = "Registrera dig";
            this.RegisterButton.UseVisualStyleBackColor = true;
            this.RegisterButton.Click += new System.EventHandler(this.RegisterButton_Click);
            // 
            // login
            // 
            this.login.Controls.Add(this.LogButton);
            this.login.Controls.Add(this.label3);
            this.login.Controls.Add(this.label2);
            this.login.Controls.Add(this.LoginPasswordBox);
            this.login.Controls.Add(this.LoginUsernameBox);
            this.login.Controls.Add(this.label1);
            this.login.Location = new System.Drawing.Point(0, 0);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(801, 452);
            this.login.TabIndex = 2;
            // 
            // LogButton
            // 
            this.LogButton.Location = new System.Drawing.Point(335, 295);
            this.LogButton.Name = "LogButton";
            this.LogButton.Size = new System.Drawing.Size(150, 50);
            this.LogButton.TabIndex = 5;
            this.LogButton.Text = "Logga in ";
            this.LogButton.UseVisualStyleBackColor = true;
            this.LogButton.Click += new System.EventHandler(this.LogButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(298, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(187, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = "Skriv in dina uppgifter";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(264, 232);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Lösenord: ";
            // 
            // LoginPasswordBox
            // 
            this.LoginPasswordBox.Location = new System.Drawing.Point(365, 229);
            this.LoginPasswordBox.Name = "LoginPasswordBox";
            this.LoginPasswordBox.Size = new System.Drawing.Size(200, 31);
            this.LoginPasswordBox.TabIndex = 2;
            // 
            // LoginUsernameBox
            // 
            this.LoginUsernameBox.Location = new System.Drawing.Point(365, 174);
            this.LoginUsernameBox.Name = "LoginUsernameBox";
            this.LoginUsernameBox.Size = new System.Drawing.Size(200, 31);
            this.LoginUsernameBox.TabIndex = 1;
            this.LoginUsernameBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(218, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Person nummer:";
            // 
            // register
            // 
            this.register.Controls.Add(this.RegButton);
            this.register.Controls.Add(this.label9);
            this.register.Controls.Add(this.numberBox);
            this.register.Controls.Add(this.mailBox);
            this.register.Controls.Add(this.passwordBox);
            this.register.Controls.Add(this.usernameBox);
            this.register.Controls.Add(this.label8);
            this.register.Controls.Add(this.label7);
            this.register.Controls.Add(this.label6);
            this.register.Controls.Add(this.label5);
            this.register.Location = new System.Drawing.Point(0, 0);
            this.register.Name = "register";
            this.register.Size = new System.Drawing.Size(801, 452);
            this.register.TabIndex = 6;
            // 
            // RegButton
            // 
            this.RegButton.Location = new System.Drawing.Point(322, 351);
            this.RegButton.Name = "RegButton";
            this.RegButton.Size = new System.Drawing.Size(112, 34);
            this.RegButton.TabIndex = 9;
            this.RegButton.Text = "Register";
            this.RegButton.UseVisualStyleBackColor = true;
            this.RegButton.Click += new System.EventHandler(this.RegButton_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(306, 65);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(174, 25);
            this.label9.TabIndex = 8;
            this.label9.Text = "Registrera ditt konto";
            // 
            // numberBox
            // 
            this.numberBox.Location = new System.Drawing.Point(260, 286);
            this.numberBox.Name = "numberBox";
            this.numberBox.Size = new System.Drawing.Size(200, 31);
            this.numberBox.TabIndex = 7;
            // 
            // mailBox
            // 
            this.mailBox.Location = new System.Drawing.Point(165, 244);
            this.mailBox.Name = "mailBox";
            this.mailBox.Size = new System.Drawing.Size(200, 31);
            this.mailBox.TabIndex = 6;
            // 
            // passwordBox
            // 
            this.passwordBox.Location = new System.Drawing.Point(206, 202);
            this.passwordBox.Name = "passwordBox";
            this.passwordBox.Size = new System.Drawing.Size(200, 31);
            this.passwordBox.TabIndex = 5;
            // 
            // usernameBox
            // 
            this.usernameBox.Location = new System.Drawing.Point(257, 152);
            this.usernameBox.Name = "usernameBox";
            this.usernameBox.Size = new System.Drawing.Size(200, 31);
            this.usernameBox.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(110, 286);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(144, 25);
            this.label8.TabIndex = 3;
            this.label8.Text = "Telefon nummer:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(110, 247);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 25);
            this.label7.TabIndex = 2;
            this.label7.Text = "Mail:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(110, 202);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 25);
            this.label6.TabIndex = 1;
            this.label6.Text = "Lösenord:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(110, 152);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(141, 25);
            this.label5.TabIndex = 0;
            this.label5.Text = "Person nummer:";
            // 
            // mainpage
            // 
            this.mainpage.Controls.Add(this.AdminAddButton);
            this.mainpage.Controls.Add(this.AdminButton);
            this.mainpage.Controls.Add(this.SearchbookButton);
            this.mainpage.Controls.Add(this.MybooksButton);
            this.mainpage.Controls.Add(this.ProfilButton);
            this.mainpage.Controls.Add(this.label10);
            this.mainpage.Location = new System.Drawing.Point(0, 0);
            this.mainpage.Name = "mainpage";
            this.mainpage.Size = new System.Drawing.Size(801, 452);
            this.mainpage.TabIndex = 10;
            this.mainpage.Paint += new System.Windows.Forms.PaintEventHandler(this.mainpage_Paint);
            // 
            // AdminAddButton
            // 
            this.AdminAddButton.Location = new System.Drawing.Point(371, 260);
            this.AdminAddButton.Name = "AdminAddButton";
            this.AdminAddButton.Size = new System.Drawing.Size(160, 34);
            this.AdminAddButton.TabIndex = 5;
            this.AdminAddButton.Text = "Redigera böcker";
            this.AdminAddButton.UseVisualStyleBackColor = true;
            this.AdminAddButton.Click += new System.EventHandler(this.AdminAddButton_Click);
            // 
            // AdminButton
            // 
            this.AdminButton.Location = new System.Drawing.Point(199, 260);
            this.AdminButton.Name = "AdminButton";
            this.AdminButton.Size = new System.Drawing.Size(160, 34);
            this.AdminButton.TabIndex = 4;
            this.AdminButton.Text = "Biblotikarie inställningar";
            this.AdminButton.UseVisualStyleBackColor = true;
            this.AdminButton.Click += new System.EventHandler(this.AdminButton_Click);
            // 
            // SearchbookButton
            // 
            this.SearchbookButton.Location = new System.Drawing.Point(150, 149);
            this.SearchbookButton.Name = "SearchbookButton";
            this.SearchbookButton.Size = new System.Drawing.Size(150, 34);
            this.SearchbookButton.TabIndex = 3;
            this.SearchbookButton.Text = "Söka böcker";
            this.SearchbookButton.UseVisualStyleBackColor = true;
            this.SearchbookButton.Click += new System.EventHandler(this.SearchbookButton_Click);
            // 
            // MybooksButton
            // 
            this.MybooksButton.CausesValidation = false;
            this.MybooksButton.Location = new System.Drawing.Point(306, 149);
            this.MybooksButton.Name = "MybooksButton";
            this.MybooksButton.Size = new System.Drawing.Size(160, 34);
            this.MybooksButton.TabIndex = 2;
            this.MybooksButton.Text = "Böcker du lånar";
            this.MybooksButton.UseVisualStyleBackColor = true;
            this.MybooksButton.Click += new System.EventHandler(this.MybooksButton_Click);
            // 
            // ProfilButton
            // 
            this.ProfilButton.Location = new System.Drawing.Point(472, 149);
            this.ProfilButton.Name = "ProfilButton";
            this.ProfilButton.Size = new System.Drawing.Size(112, 34);
            this.ProfilButton.TabIndex = 1;
            this.ProfilButton.Text = "Min profil";
            this.ProfilButton.UseVisualStyleBackColor = true;
            this.ProfilButton.Click += new System.EventHandler(this.ProfilButton_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(298, 46);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(191, 32);
            this.label10.TabIndex = 0;
            this.label10.Text = "Vad vill du göra?";
            // 
            // Profil
            // 
            this.Profil.Controls.Add(this.ProfilPassword);
            this.Profil.Controls.Add(this.ProfilUsername);
            this.Profil.Controls.Add(this.applyAdminButton);
            this.Profil.Controls.Add(this.changePasswordButton);
            this.Profil.Controls.Add(this.button3);
            this.Profil.Controls.Add(this.label13);
            this.Profil.Controls.Add(this.label12);
            this.Profil.Controls.Add(this.label11);
            this.Profil.Location = new System.Drawing.Point(0, 0);
            this.Profil.Name = "Profil";
            this.Profil.Size = new System.Drawing.Size(801, 452);
            this.Profil.TabIndex = 6;
            // 
            // ProfilPassword
            // 
            this.ProfilPassword.Location = new System.Drawing.Point(220, 123);
            this.ProfilPassword.Name = "ProfilPassword";
            this.ProfilPassword.Size = new System.Drawing.Size(150, 31);
            this.ProfilPassword.TabIndex = 7;
            // 
            // ProfilUsername
            // 
            this.ProfilUsername.Location = new System.Drawing.Point(272, 86);
            this.ProfilUsername.Name = "ProfilUsername";
            this.ProfilUsername.Size = new System.Drawing.Size(150, 31);
            this.ProfilUsername.TabIndex = 6;
            // 
            // applyAdminButton
            // 
            this.applyAdminButton.Location = new System.Drawing.Point(415, 260);
            this.applyAdminButton.Name = "applyAdminButton";
            this.applyAdminButton.Size = new System.Drawing.Size(270, 35);
            this.applyAdminButton.TabIndex = 5;
            this.applyAdminButton.Text = "Jag vill önsöka om biblotikarie";
            this.applyAdminButton.UseVisualStyleBackColor = true;
            this.applyAdminButton.Click += new System.EventHandler(this.ApplyAdmin_Click);
            // 
            // changePasswordButton
            // 
            this.changePasswordButton.Location = new System.Drawing.Point(140, 260);
            this.changePasswordButton.Name = "changePasswordButton";
            this.changePasswordButton.Size = new System.Drawing.Size(160, 34);
            this.changePasswordButton.TabIndex = 4;
            this.changePasswordButton.Text = "Ändra lösenord";
            this.changePasswordButton.UseVisualStyleBackColor = true;
            this.changePasswordButton.Click += new System.EventHandler(this.changePassword_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(3, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(112, 34);
            this.button3.TabIndex = 3;
            this.button3.Text = "MainPage";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.MainPageButton_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(94, 121);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(120, 25);
            this.label13.TabIndex = 2;
            this.label13.Text = "Ditt lösenord:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(94, 86);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(172, 25);
            this.label12.TabIndex = 1;
            this.label12.Text = "Ditt personnummer:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(298, 40);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(206, 25);
            this.label11.TabIndex = 0;
            this.label11.Text = "Välkommen till din profil";
            // 
            // searchbooks
            // 
            this.searchbooks.Controls.Add(this.button1);
            this.searchbooks.Controls.Add(this.findBookButton);
            this.searchbooks.Controls.Add(this.borrowButton);
            this.searchbooks.Controls.Add(this.bookNumberBox);
            this.searchbooks.Controls.Add(this.label4);
            this.searchbooks.Controls.Add(this.listBox);
            this.searchbooks.Controls.Add(this.searchTextBox);
            this.searchbooks.Controls.Add(this.label14);
            this.searchbooks.Location = new System.Drawing.Point(0, 0);
            this.searchbooks.Name = "searchbooks";
            this.searchbooks.Size = new System.Drawing.Size(801, 452);
            this.searchbooks.TabIndex = 8;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 34);
            this.button1.TabIndex = 7;
            this.button1.Text = "MainPage";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.MainPageButton_Click);
            // 
            // findBookButton
            // 
            this.findBookButton.Location = new System.Drawing.Point(642, 86);
            this.findBookButton.Name = "findBookButton";
            this.findBookButton.Size = new System.Drawing.Size(112, 34);
            this.findBookButton.TabIndex = 6;
            this.findBookButton.Text = "Search";
            this.findBookButton.UseVisualStyleBackColor = true;
            this.findBookButton.Click += new System.EventHandler(this.findBookButton_Click);
            // 
            // borrowButton
            // 
            this.borrowButton.Location = new System.Drawing.Point(616, 380);
            this.borrowButton.Name = "borrowButton";
            this.borrowButton.Size = new System.Drawing.Size(112, 34);
            this.borrowButton.TabIndex = 5;
            this.borrowButton.Text = "Låna";
            this.borrowButton.UseVisualStyleBackColor = true;
            this.borrowButton.Click += new System.EventHandler(this.borrowButton_Click);
            // 
            // bookNumberBox
            // 
            this.bookNumberBox.Location = new System.Drawing.Point(460, 380);
            this.bookNumberBox.Name = "bookNumberBox";
            this.bookNumberBox.Size = new System.Drawing.Size(150, 31);
            this.bookNumberBox.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 385);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(413, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Skriv in numret på boken du vill låna eller reservera";
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 25;
            this.listBox.Location = new System.Drawing.Point(29, 133);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(734, 204);
            this.listBox.TabIndex = 2;
            // 
            // searchTextBox
            // 
            this.searchTextBox.Location = new System.Drawing.Point(140, 87);
            this.searchTextBox.Name = "searchTextBox";
            this.searchTextBox.Size = new System.Drawing.Size(496, 31);
            this.searchTextBox.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(140, 46);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(492, 25);
            this.label14.TabIndex = 0;
            this.label14.Text = "Skriv in boken title, författare eller isbn för att din favorit bok";
            // 
            // Mybooks
            // 
            this.Mybooks.Controls.Add(this.returnReservedButton);
            this.Mybooks.Controls.Add(this.reservedTextBox);
            this.Mybooks.Controls.Add(this.label17);
            this.Mybooks.Controls.Add(this.borrwingListBox);
            this.Mybooks.Controls.Add(this.returnButton);
            this.Mybooks.Controls.Add(this.button6);
            this.Mybooks.Controls.Add(this.returnBox);
            this.Mybooks.Controls.Add(this.label21);
            this.Mybooks.Controls.Add(this.label16);
            this.Mybooks.Controls.Add(this.label15);
            this.Mybooks.Controls.Add(this.reservedListBox);
            this.Mybooks.Location = new System.Drawing.Point(0, 0);
            this.Mybooks.Name = "Mybooks";
            this.Mybooks.Size = new System.Drawing.Size(801, 449);
            this.Mybooks.TabIndex = 3;
            // 
            // returnReservedButton
            // 
            this.returnReservedButton.Location = new System.Drawing.Point(621, 382);
            this.returnReservedButton.Name = "returnReservedButton";
            this.returnReservedButton.Size = new System.Drawing.Size(112, 34);
            this.returnReservedButton.TabIndex = 14;
            this.returnReservedButton.Text = "Lämna tillbaka";
            this.returnReservedButton.UseVisualStyleBackColor = true;
            this.returnReservedButton.Click += new System.EventHandler(this.returnReservedButton_Click);
            // 
            // reservedTextBox
            // 
            this.reservedTextBox.Location = new System.Drawing.Point(431, 385);
            this.reservedTextBox.Name = "reservedTextBox";
            this.reservedTextBox.Size = new System.Drawing.Size(184, 31);
            this.reservedTextBox.TabIndex = 13;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(27, 388);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(391, 25);
            this.label17.TabIndex = 12;
            this.label17.Text = "Skriv in boken du reservar och vill lämna tillbaka";
            // 
            // borrwingListBox
            // 
            this.borrwingListBox.FormattingEnabled = true;
            this.borrwingListBox.ItemHeight = 25;
            this.borrwingListBox.Location = new System.Drawing.Point(23, 78);
            this.borrwingListBox.Name = "borrwingListBox";
            this.borrwingListBox.Size = new System.Drawing.Size(264, 229);
            this.borrwingListBox.TabIndex = 10;
            // 
            // returnButton
            // 
            this.returnButton.Location = new System.Drawing.Point(639, 331);
            this.returnButton.Name = "returnButton";
            this.returnButton.Size = new System.Drawing.Size(112, 34);
            this.returnButton.TabIndex = 9;
            this.returnButton.Text = "Lämna tillbaka";
            this.returnButton.UseVisualStyleBackColor = true;
            this.returnButton.Click += new System.EventHandler(this.returnButton_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(3, 3);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(112, 34);
            this.button6.TabIndex = 8;
            this.button6.Text = "Main page";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.MainPageButton_Click);
            // 
            // returnBox
            // 
            this.returnBox.Location = new System.Drawing.Point(440, 334);
            this.returnBox.Name = "returnBox";
            this.returnBox.Size = new System.Drawing.Size(184, 31);
            this.returnBox.TabIndex = 7;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(24, 340);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(407, 25);
            this.label21.TabIndex = 6;
            this.label21.Text = "Skriv in boken som du lånar och vill lämna tillbaka";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(365, 40);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(207, 25);
            this.label16.TabIndex = 1;
            this.label16.Text = "Böcker du har reserverat:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(24, 40);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(196, 25);
            this.label15.TabIndex = 0;
            this.label15.Text = "Böcker du lånar just nu:";
            // 
            // reservedListBox
            // 
            this.reservedListBox.FormattingEnabled = true;
            this.reservedListBox.ItemHeight = 25;
            this.reservedListBox.Location = new System.Drawing.Point(366, 80);
            this.reservedListBox.Name = "reservedListBox";
            this.reservedListBox.Size = new System.Drawing.Size(268, 229);
            this.reservedListBox.TabIndex = 11;
            // 
            // AdminSettings
            // 
            this.AdminSettings.Controls.Add(this.panel1);
            this.AdminSettings.Controls.Add(this.showAllUsersButton);
            this.AdminSettings.Controls.Add(this.removeUserButton);
            this.AdminSettings.Controls.Add(this.addUserButton);
            this.AdminSettings.Controls.Add(this.button7);
            this.AdminSettings.Controls.Add(this.label22);
            this.AdminSettings.Location = new System.Drawing.Point(0, 0);
            this.AdminSettings.Name = "AdminSettings";
            this.AdminSettings.Size = new System.Drawing.Size(801, 449);
            this.AdminSettings.TabIndex = 9;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(779, 418);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(300, 150);
            this.panel1.TabIndex = 5;
            // 
            // showAllUsersButton
            // 
            this.showAllUsersButton.Location = new System.Drawing.Point(590, 207);
            this.showAllUsersButton.Name = "showAllUsersButton";
            this.showAllUsersButton.Size = new System.Drawing.Size(161, 34);
            this.showAllUsersButton.TabIndex = 4;
            this.showAllUsersButton.Text = "Lista användare";
            this.showAllUsersButton.UseVisualStyleBackColor = true;
            this.showAllUsersButton.Click += new System.EventHandler(this.showAllUsersButton_Click);
            // 
            // removeUserButton
            // 
            this.removeUserButton.Location = new System.Drawing.Point(274, 208);
            this.removeUserButton.Name = "removeUserButton";
            this.removeUserButton.Size = new System.Drawing.Size(291, 34);
            this.removeUserButton.TabIndex = 3;
            this.removeUserButton.Text = "Ta bort en användare";
            this.removeUserButton.UseVisualStyleBackColor = true;
            this.removeUserButton.Click += new System.EventHandler(this.removeUserButton_Click);
            // 
            // addUserButton
            // 
            this.addUserButton.Location = new System.Drawing.Point(41, 207);
            this.addUserButton.Name = "addUserButton";
            this.addUserButton.Size = new System.Drawing.Size(201, 34);
            this.addUserButton.TabIndex = 2;
            this.addUserButton.Text = "Lägga till användare";
            this.addUserButton.UseVisualStyleBackColor = true;
            this.addUserButton.Click += new System.EventHandler(this.addUserButton_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(3, 3);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(112, 34);
            this.button7.TabIndex = 1;
            this.button7.Text = "MainPage";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.MainPageButton_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(322, 37);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(168, 25);
            this.label22.TabIndex = 0;
            this.label22.Text = "Du har tre alternativ";
            // 
            // showAllUsers
            // 
            this.showAllUsers.Controls.Add(this.allUsersBox);
            this.showAllUsers.Controls.Add(this.MainPageButton);
            this.showAllUsers.Location = new System.Drawing.Point(0, 0);
            this.showAllUsers.Name = "showAllUsers";
            this.showAllUsers.Size = new System.Drawing.Size(801, 449);
            this.showAllUsers.TabIndex = 5;
            // 
            // allUsersBox
            // 
            this.allUsersBox.FormattingEnabled = true;
            this.allUsersBox.ItemHeight = 25;
            this.allUsersBox.Location = new System.Drawing.Point(23, 49);
            this.allUsersBox.Name = "allUsersBox";
            this.allUsersBox.Size = new System.Drawing.Size(765, 354);
            this.allUsersBox.TabIndex = 1;
            // 
            // MainPageButton
            // 
            this.MainPageButton.Location = new System.Drawing.Point(0, 0);
            this.MainPageButton.Name = "MainPageButton";
            this.MainPageButton.Size = new System.Drawing.Size(112, 34);
            this.MainPageButton.TabIndex = 0;
            this.MainPageButton.Text = "MainPage";
            this.MainPageButton.UseVisualStyleBackColor = true;
            this.MainPageButton.Click += new System.EventHandler(this.MainPageButton_Click);
            // 
            // AdminBookSettings
            // 
            this.AdminBookSettings.Controls.Add(this.button14);
            this.AdminBookSettings.Controls.Add(this.button13);
            this.AdminBookSettings.Controls.Add(this.button12);
            this.AdminBookSettings.Controls.Add(this.button11);
            this.AdminBookSettings.Controls.Add(this.label23);
            this.AdminBookSettings.Location = new System.Drawing.Point(0, 0);
            this.AdminBookSettings.Name = "AdminBookSettings";
            this.AdminBookSettings.Size = new System.Drawing.Size(801, 449);
            this.AdminBookSettings.TabIndex = 5;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(524, 223);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(161, 34);
            this.button14.TabIndex = 4;
            this.button14.Text = "Redigera en bok";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.editBookRoute_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(306, 223);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(154, 34);
            this.button13.TabIndex = 3;
            this.button13.Text = "Ta bort en bok";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.removeButton_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(94, 223);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(160, 34);
            this.button12.TabIndex = 2;
            this.button12.Text = "Lägga till en bok";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(3, 3);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(112, 34);
            this.button11.TabIndex = 1;
            this.button11.Text = "Mainpage";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(306, 46);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(168, 25);
            this.label23.TabIndex = 0;
            this.label23.Text = "Du har tre alternativ";
            // 
            // changePassword
            // 
            this.changePassword.Controls.Add(this.button10);
            this.changePassword.Controls.Add(this.button2);
            this.changePassword.Controls.Add(this.passwordButton);
            this.changePassword.Controls.Add(this.changePasswordTextBox);
            this.changePassword.Controls.Add(this.label18);
            this.changePassword.Location = new System.Drawing.Point(0, 0);
            this.changePassword.Name = "changePassword";
            this.changePassword.Size = new System.Drawing.Size(801, 452);
            this.changePassword.TabIndex = 5;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(0, -3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 34);
            this.button2.TabIndex = 3;
            this.button2.Text = "MainPage";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.MainPageButton_Click);
            // 
            // passwordButton
            // 
            this.passwordButton.Location = new System.Drawing.Point(686, 195);
            this.passwordButton.Name = "passwordButton";
            this.passwordButton.Size = new System.Drawing.Size(112, 34);
            this.passwordButton.TabIndex = 2;
            this.passwordButton.Text = "Byt";
            this.passwordButton.UseVisualStyleBackColor = true;
            this.passwordButton.Click += new System.EventHandler(this.changePassword_Click_1);
            // 
            // changePasswordTextBox
            // 
            this.changePasswordTextBox.Location = new System.Drawing.Point(328, 197);
            this.changePasswordTextBox.Name = "changePasswordTextBox";
            this.changePasswordTextBox.Size = new System.Drawing.Size(357, 31);
            this.changePasswordTextBox.TabIndex = 1;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 197);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(310, 25);
            this.label18.TabIndex = 0;
            this.label18.Text = "Skriv vad du vill byta ditt lösenord till:";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // createBook
            // 
            this.createBook.Controls.Add(this.button4);
            this.createBook.Controls.Add(this.createBookButton);
            this.createBook.Controls.Add(this.stockTextBox);
            this.createBook.Controls.Add(this.isbnTextBox);
            this.createBook.Controls.Add(this.yearTextBox);
            this.createBook.Controls.Add(this.authorTextBox);
            this.createBook.Controls.Add(this.titleTextBox);
            this.createBook.Controls.Add(this.label26);
            this.createBook.Controls.Add(this.label25);
            this.createBook.Controls.Add(this.label24);
            this.createBook.Controls.Add(this.label20);
            this.createBook.Controls.Add(this.label19);
            this.createBook.Location = new System.Drawing.Point(0, 0);
            this.createBook.Name = "createBook";
            this.createBook.Size = new System.Drawing.Size(801, 452);
            this.createBook.TabIndex = 5;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(0, 0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(112, 34);
            this.button4.TabIndex = 11;
            this.button4.Text = "MainPage";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.MainPageButton_Click);
            // 
            // createBookButton
            // 
            this.createBookButton.Location = new System.Drawing.Point(23, 340);
            this.createBookButton.Name = "createBookButton";
            this.createBookButton.Size = new System.Drawing.Size(765, 34);
            this.createBookButton.TabIndex = 10;
            this.createBookButton.Text = "Skapa book";
            this.createBookButton.UseVisualStyleBackColor = true;
            this.createBookButton.Click += new System.EventHandler(this.createBookButton_Click);
            // 
            // stockTextBox
            // 
            this.stockTextBox.Location = new System.Drawing.Point(346, 262);
            this.stockTextBox.Name = "stockTextBox";
            this.stockTextBox.Size = new System.Drawing.Size(150, 31);
            this.stockTextBox.TabIndex = 9;
            // 
            // isbnTextBox
            // 
            this.isbnTextBox.Location = new System.Drawing.Point(121, 204);
            this.isbnTextBox.Name = "isbnTextBox";
            this.isbnTextBox.Size = new System.Drawing.Size(150, 31);
            this.isbnTextBox.TabIndex = 8;
            // 
            // yearTextBox
            // 
            this.yearTextBox.Location = new System.Drawing.Point(229, 158);
            this.yearTextBox.Name = "yearTextBox";
            this.yearTextBox.Size = new System.Drawing.Size(150, 31);
            this.yearTextBox.TabIndex = 7;
            // 
            // authorTextBox
            // 
            this.authorTextBox.Location = new System.Drawing.Point(140, 114);
            this.authorTextBox.Name = "authorTextBox";
            this.authorTextBox.Size = new System.Drawing.Size(150, 31);
            this.authorTextBox.TabIndex = 6;
            // 
            // titleTextBox
            // 
            this.titleTextBox.Location = new System.Drawing.Point(118, 53);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new System.Drawing.Size(150, 31);
            this.titleTextBox.TabIndex = 5;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(23, 260);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(317, 25);
            this.label26.TabIndex = 4;
            this.label26.Text = "Skriv hur mycket lager vi har av boken:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(23, 204);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(92, 25);
            this.label25.TabIndex = 3;
            this.label25.Text = "Skriv isbn:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(23, 158);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(200, 25);
            this.label24.TabIndex = 2;
            this.label24.Text = "Skriv år boken släpptes:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(23, 111);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(118, 25);
            this.label20.TabIndex = 1;
            this.label20.Text = "Skriv föfattre:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(24, 53);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(88, 25);
            this.label19.TabIndex = 0;
            this.label19.Text = "Skriv title:";
            // 
            // removeBook
            // 
            this.removeBook.Controls.Add(this.button5);
            this.removeBook.Controls.Add(this.booksBox);
            this.removeBook.Controls.Add(this.removeBookButton);
            this.removeBook.Controls.Add(this.removeBookTextBox);
            this.removeBook.Controls.Add(this.label27);
            this.removeBook.Location = new System.Drawing.Point(0, 0);
            this.removeBook.Name = "removeBook";
            this.removeBook.Size = new System.Drawing.Size(798, 446);
            this.removeBook.TabIndex = 5;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(0, -3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(112, 34);
            this.button5.TabIndex = 4;
            this.button5.Text = "MainPage";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.MainPageButton_Click);
            // 
            // booksBox
            // 
            this.booksBox.FormattingEnabled = true;
            this.booksBox.ItemHeight = 25;
            this.booksBox.Location = new System.Drawing.Point(61, 37);
            this.booksBox.Name = "booksBox";
            this.booksBox.Size = new System.Drawing.Size(677, 304);
            this.booksBox.TabIndex = 3;
            // 
            // removeBookButton
            // 
            this.removeBookButton.Location = new System.Drawing.Point(570, 360);
            this.removeBookButton.Name = "removeBookButton";
            this.removeBookButton.Size = new System.Drawing.Size(178, 34);
            this.removeBookButton.TabIndex = 2;
            this.removeBookButton.Text = "Ta bort book";
            this.removeBookButton.UseVisualStyleBackColor = true;
            this.removeBookButton.Click += new System.EventHandler(this.removeBookButton_Click);
            // 
            // removeBookTextBox
            // 
            this.removeBookTextBox.Location = new System.Drawing.Point(409, 362);
            this.removeBookTextBox.Name = "removeBookTextBox";
            this.removeBookTextBox.Size = new System.Drawing.Size(150, 31);
            this.removeBookTextBox.TabIndex = 1;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(75, 362);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(328, 25);
            this.label27.TabIndex = 0;
            this.label27.Text = "Skriv boken nummer som du vill ta bort";
            this.label27.Click += new System.EventHandler(this.label27_Click);
            // 
            // editBook
            // 
            this.editBook.Controls.Add(this.button9);
            this.editBook.Controls.Add(this.bookButtonPick);
            this.editBook.Controls.Add(this.bookNumberEdit);
            this.editBook.Controls.Add(this.label28);
            this.editBook.Controls.Add(this.bookBoxList);
            this.editBook.Location = new System.Drawing.Point(0, 0);
            this.editBook.Name = "editBook";
            this.editBook.Size = new System.Drawing.Size(801, 452);
            this.editBook.TabIndex = 5;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(0, -3);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(112, 34);
            this.button9.TabIndex = 4;
            this.button9.Text = "MainPage";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.MainPageButton_Click);
            // 
            // bookButtonPick
            // 
            this.bookButtonPick.Location = new System.Drawing.Point(536, 331);
            this.bookButtonPick.Name = "bookButtonPick";
            this.bookButtonPick.Size = new System.Drawing.Size(112, 34);
            this.bookButtonPick.TabIndex = 3;
            this.bookButtonPick.Text = "Välj";
            this.bookButtonPick.UseVisualStyleBackColor = true;
            this.bookButtonPick.Click += new System.EventHandler(this.bookButtonPick_Click);
            // 
            // bookNumberEdit
            // 
            this.bookNumberEdit.Location = new System.Drawing.Point(371, 333);
            this.bookNumberEdit.Name = "bookNumberEdit";
            this.bookNumberEdit.Size = new System.Drawing.Size(150, 31);
            this.bookNumberEdit.TabIndex = 2;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(12, 336);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(361, 25);
            this.label28.TabIndex = 1;
            this.label28.Text = "Skriv boknumret på den bok du vill redigera";
            // 
            // bookBoxList
            // 
            this.bookBoxList.FormattingEnabled = true;
            this.bookBoxList.ItemHeight = 25;
            this.bookBoxList.Location = new System.Drawing.Point(12, 40);
            this.bookBoxList.Name = "bookBoxList";
            this.bookBoxList.Size = new System.Drawing.Size(776, 279);
            this.bookBoxList.TabIndex = 0;
            // 
            // editBookPicked
            // 
            this.editBookPicked.Controls.Add(this.button8);
            this.editBookPicked.Controls.Add(this.editBookButton);
            this.editBookPicked.Controls.Add(this.whatToChangeItTo);
            this.editBookPicked.Controls.Add(this.label30);
            this.editBookPicked.Controls.Add(this.whatToChange);
            this.editBookPicked.Controls.Add(this.label29);
            this.editBookPicked.Controls.Add(this.bookEditBox);
            this.editBookPicked.Location = new System.Drawing.Point(0, 0);
            this.editBookPicked.Name = "editBookPicked";
            this.editBookPicked.Size = new System.Drawing.Size(801, 449);
            this.editBookPicked.TabIndex = 4;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(0, -3);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(112, 34);
            this.button8.TabIndex = 6;
            this.button8.Text = "MainPage";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.MainPageButton_Click);
            // 
            // editBookButton
            // 
            this.editBookButton.Location = new System.Drawing.Point(16, 385);
            this.editBookButton.Name = "editBookButton";
            this.editBookButton.Size = new System.Drawing.Size(747, 34);
            this.editBookButton.TabIndex = 5;
            this.editBookButton.Text = "Redigera";
            this.editBookButton.UseVisualStyleBackColor = true;
            this.editBookButton.Click += new System.EventHandler(this.editBookButton_Click);
            // 
            // whatToChangeItTo
            // 
            this.whatToChangeItTo.Location = new System.Drawing.Point(218, 340);
            this.whatToChangeItTo.Name = "whatToChangeItTo";
            this.whatToChangeItTo.Size = new System.Drawing.Size(133, 31);
            this.whatToChangeItTo.TabIndex = 4;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(21, 344);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(199, 25);
            this.label30.TabIndex = 3;
            this.label30.Text = "Skriv vad du vill det till: ";
            // 
            // whatToChange
            // 
            this.whatToChange.Location = new System.Drawing.Point(293, 303);
            this.whatToChange.Name = "whatToChange";
            this.whatToChange.Size = new System.Drawing.Size(133, 31);
            this.whatToChange.TabIndex = 2;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(16, 306);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(274, 25);
            this.label29.TabIndex = 1;
            this.label29.Text = "Skriv vad du vill ändra. Nummer: ";
            // 
            // bookEditBox
            // 
            this.bookEditBox.FormattingEnabled = true;
            this.bookEditBox.ItemHeight = 25;
            this.bookEditBox.Location = new System.Drawing.Point(23, 40);
            this.bookEditBox.Name = "bookEditBox";
            this.bookEditBox.Size = new System.Drawing.Size(740, 229);
            this.bookEditBox.TabIndex = 0;
            // 
            // createUser
            // 
            this.createUser.Controls.Add(this.button15);
            this.createUser.Controls.Add(this.createUserButton);
            this.createUser.Controls.Add(this.numberText);
            this.createUser.Controls.Add(this.mailText);
            this.createUser.Controls.Add(this.passwordText);
            this.createUser.Controls.Add(this.usernameText);
            this.createUser.Controls.Add(this.label34);
            this.createUser.Controls.Add(this.label33);
            this.createUser.Controls.Add(this.label32);
            this.createUser.Controls.Add(this.label31);
            this.createUser.Location = new System.Drawing.Point(0, 0);
            this.createUser.Name = "createUser";
            this.createUser.Size = new System.Drawing.Size(798, 452);
            this.createUser.TabIndex = 12;
            // 
            // createUserButton
            // 
            this.createUserButton.Location = new System.Drawing.Point(16, 183);
            this.createUserButton.Name = "createUserButton";
            this.createUserButton.Size = new System.Drawing.Size(406, 34);
            this.createUserButton.TabIndex = 9;
            this.createUserButton.Text = "Skapa användare";
            this.createUserButton.UseVisualStyleBackColor = true;
            this.createUserButton.Click += new System.EventHandler(this.createUserButton_Click);
            // 
            // numberText
            // 
            this.numberText.Location = new System.Drawing.Point(94, 136);
            this.numberText.Name = "numberText";
            this.numberText.Size = new System.Drawing.Size(297, 31);
            this.numberText.TabIndex = 8;
            // 
            // mailText
            // 
            this.mailText.Location = new System.Drawing.Point(67, 102);
            this.mailText.Name = "mailText";
            this.mailText.Size = new System.Drawing.Size(297, 31);
            this.mailText.TabIndex = 7;
            // 
            // passwordText
            // 
            this.passwordText.Location = new System.Drawing.Point(106, 65);
            this.passwordText.Name = "passwordText";
            this.passwordText.Size = new System.Drawing.Size(297, 31);
            this.passwordText.TabIndex = 6;
            // 
            // usernameText
            // 
            this.usernameText.Location = new System.Drawing.Point(82, 28);
            this.usernameText.Name = "usernameText";
            this.usernameText.Size = new System.Drawing.Size(297, 31);
            this.usernameText.TabIndex = 5;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(12, 136);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(81, 25);
            this.label34.TabIndex = 3;
            this.label34.Text = "Number:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(12, 102);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(49, 25);
            this.label33.TabIndex = 2;
            this.label33.Text = "Mail:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(12, 65);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(90, 25);
            this.label32.TabIndex = 1;
            this.label32.Text = "Lösenord:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(12, 28);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(64, 25);
            this.label31.TabIndex = 0;
            this.label31.Text = "Namn:";
            // 
            // RemoveUser
            // 
            this.RemoveUser.Controls.Add(this.button16);
            this.RemoveUser.Controls.Add(this.removeButton);
            this.RemoveUser.Controls.Add(this.removeUserTextBox);
            this.RemoveUser.Controls.Add(this.label35);
            this.RemoveUser.Controls.Add(this.userListBox);
            this.RemoveUser.Location = new System.Drawing.Point(0, 0);
            this.RemoveUser.Name = "RemoveUser";
            this.RemoveUser.Size = new System.Drawing.Size(801, 455);
            this.RemoveUser.TabIndex = 6;
            // 
            // removeButton
            // 
            this.removeButton.Location = new System.Drawing.Point(573, 358);
            this.removeButton.Name = "removeButton";
            this.removeButton.Size = new System.Drawing.Size(175, 34);
            this.removeButton.TabIndex = 3;
            this.removeButton.Text = "Ta bort användare";
            this.removeButton.UseVisualStyleBackColor = true;
            this.removeButton.Click += new System.EventHandler(this.removeButton_Click_1);
            // 
            // removeUserTextBox
            // 
            this.removeUserTextBox.Location = new System.Drawing.Point(354, 362);
            this.removeUserTextBox.Name = "removeUserTextBox";
            this.removeUserTextBox.Size = new System.Drawing.Size(205, 31);
            this.removeUserTextBox.TabIndex = 2;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(46, 363);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(312, 25);
            this.label35.TabIndex = 1;
            this.label35.Text = "Skriv idet på användare du vill ta bort:";
            // 
            // userListBox
            // 
            this.userListBox.FormattingEnabled = true;
            this.userListBox.ItemHeight = 25;
            this.userListBox.Location = new System.Drawing.Point(41, 28);
            this.userListBox.Name = "userListBox";
            this.userListBox.Size = new System.Drawing.Size(722, 304);
            this.userListBox.TabIndex = 0;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(344, 209);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(112, 34);
            this.button10.TabIndex = 9;
            this.button10.Text = "Main page";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(561, 131);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(112, 34);
            this.button15.TabIndex = 10;
            this.button15.Text = "MainPage";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.MainPageButton_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(0, -3);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(112, 34);
            this.button16.TabIndex = 4;
            this.button16.Text = "MainPage";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.MainPageButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.choice);
            this.Controls.Add(this.changePassword);
            this.Controls.Add(this.createUser);
            this.Controls.Add(this.createBook);
            this.Controls.Add(this.removeBook);
            this.Controls.Add(this.editBookPicked);
            this.Controls.Add(this.editBook);
            this.Controls.Add(this.AdminBookSettings);
            this.Controls.Add(this.showAllUsers);
            this.Controls.Add(this.RemoveUser);
            this.Controls.Add(this.AdminSettings);
            this.Controls.Add(this.Mybooks);
            this.Controls.Add(this.searchbooks);
            this.Controls.Add(this.Profil);
            this.Controls.Add(this.mainpage);
            this.Controls.Add(this.register);
            this.Controls.Add(this.login);
            this.Name = "Form1";
            this.Text = "Form1";
            this.choice.ResumeLayout(false);
            this.login.ResumeLayout(false);
            this.login.PerformLayout();
            this.register.ResumeLayout(false);
            this.register.PerformLayout();
            this.mainpage.ResumeLayout(false);
            this.mainpage.PerformLayout();
            this.Profil.ResumeLayout(false);
            this.Profil.PerformLayout();
            this.searchbooks.ResumeLayout(false);
            this.searchbooks.PerformLayout();
            this.Mybooks.ResumeLayout(false);
            this.Mybooks.PerformLayout();
            this.AdminSettings.ResumeLayout(false);
            this.AdminSettings.PerformLayout();
            this.showAllUsers.ResumeLayout(false);
            this.AdminBookSettings.ResumeLayout(false);
            this.AdminBookSettings.PerformLayout();
            this.changePassword.ResumeLayout(false);
            this.changePassword.PerformLayout();
            this.createBook.ResumeLayout(false);
            this.createBook.PerformLayout();
            this.removeBook.ResumeLayout(false);
            this.removeBook.PerformLayout();
            this.editBook.ResumeLayout(false);
            this.editBook.PerformLayout();
            this.editBookPicked.ResumeLayout(false);
            this.editBookPicked.PerformLayout();
            this.createUser.ResumeLayout(false);
            this.createUser.PerformLayout();
            this.RemoveUser.ResumeLayout(false);
            this.RemoveUser.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel choice;
        private Button LoginButton;
        private Button RegisterButton;
        private Panel login;
        private TextBox LoginUsernameBox;
        private Label label1;
        private Button LogButton;
        private Label label3;
        private Label label2;
        private TextBox LoginPasswordBox;
        private Panel register;
        private Button RegButton;
        private Label label9;
        private TextBox numberBox;
        private TextBox mailBox;
        private TextBox passwordBox;
        private TextBox usernameBox;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Panel mainpage;
        private Button AdminAddButton;
        private Button AdminButton;
        private Button SearchbookButton;
        private Button MybooksButton;
        private Button ProfilButton;
        private Label label10;
        private Panel Profil;
        private TextBox ProfilPassword;
        private TextBox ProfilUsername;
        private Button applyAdminButton;
        private Button changePasswordButton;
        private Button button3;
        private Label label13;
        private Label label12;
        private Label label11;
        private Panel searchbooks;
        private TextBox searchTextBox;
        private Label label14;
        private Panel Mybooks;
        private Button button6;
        private TextBox returnBox;
        private Label label21;
        private Label label16;
        private Label label15;
        private Panel AdminSettings;
        private Button showAllUsersButton;
        private Button removeUserButton;
        private Button addUserButton;
        private Button button7;
        private Label label22;
        private Panel AdminBookSettings;
        private Button button14;
        private Button button13;
        private Button button12;
        private Button button11;
        private Label label23;
        private Button findBookButton;
        private Button borrowButton;
        private TextBox bookNumberBox;
        private Label label4;
        private ListBox listBox;
        private Button returnButton;
        private ListBox reservedListBox;
        private ListBox borrwingListBox;
        private Button returnReservedButton;
        private TextBox reservedTextBox;
        private Label label17;
        private Panel changePassword;
        private Label label18;
        private Button passwordButton;
        private TextBox changePasswordTextBox;
        private Panel createBook;
        private Button createBookButton;
        private TextBox stockTextBox;
        private TextBox isbnTextBox;
        private TextBox yearTextBox;
        private TextBox authorTextBox;
        private TextBox titleTextBox;
        private Label label26;
        private Label label25;
        private Label label24;
        private Label label20;
        private Label label19;
        private Panel removeBook;
        private Label label27;
        private ListBox booksBox;
        private Button removeBookButton;
        private TextBox removeBookTextBox;
        private Panel editBook;
        private ListBox bookBoxList;
        private Button bookButtonPick;
        private TextBox bookNumberEdit;
        private Label label28;
        private Panel editBookPicked;
        private Button editBookButton;
        private TextBox whatToChangeItTo;
        private Label label30;
        private TextBox whatToChange;
        private Label label29;
        private ListBox bookEditBox;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Panel showAllUsers;
        private Button MainPageButton;
        private Button button1;
        private ListBox allUsersBox;
        private Button button2;
        private Button button4;
        private Button button5;
        private Button button9;
        private Button button8;
        private Panel createUser;
        private Label label34;
        private Label label33;
        private Label label32;
        private Label label31;
        private TextBox usernameText;
        private Button createUserButton;
        private TextBox numberText;
        private TextBox mailText;
        private TextBox passwordText;
        private Panel RemoveUser;
        private Button removeButton;
        private TextBox removeUserTextBox;
        private Label label35;
        private ListBox userListBox;
        private Panel panel1;
        private Button button10;
        private Button button15;
        private Button button16;
    }
}