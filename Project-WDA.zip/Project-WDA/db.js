const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('database.db');


//Create three tables, players, trophies and users
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS players (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      position TEXT,
      number INTEGER,
      goals INTEGER,
      image TEXT
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS trophies (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT,
      season TEXT,
      competition TEXT
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE,
      passwordHash TEXT
    )
  `);


  db.get("SELECT COUNT(*) AS count FROM users", (err, row) => {
    if (row.count === 0) {
      const bcrypt = require('bcrypt');
      const plainPassword = "wd#ff2025";
      const saltRounds = 10;

      // Hash password before sending to database
      bcrypt.hash(plainPassword, saltRounds, (err, hash) => {
        if (err) throw err;
        db.run("INSERT INTO users (username, passwordHash) VALUES (?, ?)", ["admin", hash]);
        console.log("Seeded admin user with username 'admin' and password 'wd#ff2025'");
      });
    }
  });

  db.get("SELECT COUNT(*) AS count FROM players", (err, row) => {
    if (row.count === 0) {
      const stmt = db.prepare("INSERT INTO players (name, position, number, goals, image) VALUES (?,?,?,?,?)");
      stmt.run("Robert Lewandowski", "Forward", 9, 15, "/images/robertlewandowski.png");
      stmt.run("Pedri Gonzalez", "Midfielder", 8, 5, "/images/pedrogonzalez.png");
      stmt.run("Marc-André ter Stegen", "Goalkeeper", 1, 0, "/images/MarcAndreterStegen.png");
      stmt.run("Ronald Araújo", "Defender", 4, 2, "/images/ronaldoaraujo.png");
      stmt.run("Lamine Yamal", "Forward", 10, 7, "/images/lamineyamal.png");
      stmt.finalize();
    }
  });


  db.get("SELECT COUNT(*) AS count FROM trophies", (err, row) => {
    if (row.count === 0) {
      const stmt = db.prepare("INSERT INTO trophies (title, season, competition) VALUES (?,?,?)");
      stmt.run("La Liga", "2022/23", "Domestic League");
      stmt.run("Copa del Rey", "2020/21", "Domestic Cup");
      stmt.run("UEFA Champions League", "2014/15", "European");
      stmt.run("Supercopa de España", "2018/19", "Domestic Cup");
      stmt.run("FIFA Club World Cup", "2015", "International");
      stmt.finalize();
    }
  });
});

module.exports = db;