/*
Sebastian Alfredsson - sebastian.alfredsson10@gmail.com or 

Target grade: 3

Project Web Dev Fun - 2025

Admininistrator login: admin
Administrator password: "wd#ff2025" 
*/


const express = require('express');
const { engine } = require('express-handlebars');
const session = require('express-session');
const db = require('./db');
const bcrypt = require('bcrypt');

const app = express();
const PORT = 5000;

//middleware
app.use(express.urlencoded({ extended: false }));

//Make it easy to use files from public
app.use(express.static('public'));

//Setup handlebars
app.engine('handlebars', engine({ defaultLayout: 'main' }));
app.set('view engine', 'handlebars');
app.set('views', './views');


app.use(session({
  secret: 'supersecretkey',
  resave: false,
  saveUninitialized: true
}));


app.use((req, res, next) => {
  res.locals.session = req.session;
  next();
});

//homepage route
app.get('/', (req, res) => {
  res.render('home');
});

//Show players
app.get('/players', (req, res) => {
  db.all("SELECT * FROM players", [], (err, rows) => {
    if (err) {
      return res.status(500).send("Database error: " + err.message);
    }
    res.render('players', { players: rows });
  });
});

app.get('/players/new', (req, res) => {
  if (!req.session.isLoggedIn) {
    return res.redirect('/login');
  }
  res.render('newPlayer');
});

app.get('/players/:id', (req, res) => {
  db.get("SELECT * FROM players WHERE id = ?", [req.params.id], (err, row) => {
    if (err) {
      return res.status(500).send("Database error: " + err.message);
    }
    if (!row) {
      return res.status(404).send("Player not found");
    }
    res.render('playerDetail', { player: row });
  });
});

app.get('/players/:id/edit', (req, res) => {
  if (!req.session.isLoggedIn) {
    return res.redirect('/login');
  }
  db.get("SELECT * FROM players WHERE id = ?", [req.params.id], (err, row) => {
    if (err) return res.status(500).send("DB error");
    res.render('editPlayer', { player: row });
  });
});

app.get('/trophies', (req, res) => {
  db.all("SELECT * FROM trophies", [], (err, rows) => {
    if (err) {
      return res.status(500).send("Database error: " + err.message);
    }
    res.render('trophies', { trophies: rows });
  });
});



app.get('/about', (req, res) => {
  res.render('about');
});


app.get('/contact', (req, res) => {
  res.render('contact');
});


app.get('/login', (req, res) => {
  res.render('login');
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;

  db.get("SELECT * FROM users WHERE username = ?", [username], (err, user) => {
    if (err) return res.status(500).send("DB error");
    if (!user) return res.status(401).send("Invalid username or password");

    //compare passwored with hashed pasword
    bcrypt.compare(password, user.passwordHash, (err, result) => {
      if (result) {
        req.session.isLoggedIn = true;
        req.session.username = user.username;
        res.redirect('/');
      } else {
        res.status(401).send("Invalid username or password");
      }
    });
  });
});

app.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});

app.post('/players/new', (req, res) => {
  if (!req.session.isLoggedIn) {
    return res.redirect('/login');
  }
  const { name, position, number, goals } = req.body;
  db.run(
    "INSERT INTO players (name, position, number, goals) VALUES (?,?,?,?)",
    [name, position, number, goals],
    (err) => {
      if (err) {
        return res.status(500).send("Database error: " + err.message);
      }
      res.redirect('/players');
    }
  );
});

app.post('/players/:id/edit', (req, res) => {
  if (!req.session.isLoggedIn) {
    return res.redirect('/login');
  }
  const { name, position, number, goals } = req.body;
  db.run(
    "UPDATE players SET name=?, position=?, number=?, goals=? WHERE id=?",
    [name, position, number, goals, req.params.id],
    (err) => {
      if (err) return res.status(500).send("DB error");
      res.redirect('/players/' + req.params.id);
    }
  );
});

app.post('/players/:id/delete', (req, res) => {
  if (!req.session.isLoggedIn) {
    return res.redirect('/login');
  }
  db.run("DELETE FROM players WHERE id = ?", [req.params.id], (err) => {
    if (err) return res.status(500).send("DB error");
    res.redirect('/players');
  });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});